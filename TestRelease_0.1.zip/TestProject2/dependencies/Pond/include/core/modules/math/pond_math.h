#pragma once
#include "../../pond_basic_structs.h"
#include "../../pond_core.h"

POND_API Pond_Vector2Int Pond_GetNullVector2(void);

