#include "pond.h"

void Init(void);
void Update(void);
void Draw(void);

void Init(void)
{

}

void Update(void)
{

}

void Draw(void)
{
	Pond_Colour red = { 255, 0, 0, 255 };

	Pond_DrawCircle(100, 100, 50, red, 1);
}

int main()
{
	Pond_Init(&Init, &Update, &Draw);
	Pond_InitAudioSystem(24, 10, 20);
	Pond_Run(0, 500, 500, "Test", 1);
}