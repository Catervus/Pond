#pragma once

#include <windows.h>

#include <SDL.h>
#ifdef main
	#undef main // WHAT
#endif


#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>



